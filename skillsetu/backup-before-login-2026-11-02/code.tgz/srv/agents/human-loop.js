// Agent 6: Human-in-the-Loop. Not an AI. Hands the case to a human counsellor, records disputes
// against the AI, and reports the counsellor's decision back. Nothing goes to an employer without a person's OK.
const { label, keywordSkills, isHindi } = require('./lib');

// "I don't know Excel": the person is the authority on their own skills, so the skill comes off the file at once.
const DENIES = /don[’']?t know|do not know|don[’']?t have|never (used|done|did)|can[’']?t|cannot|not good at|no idea|नहीं आता|नहीं आती|नहीं जानत|नहीं किया|nahi aata|nahi aati/i;
const DISPUTE = /don[’']?t know|do not know|never (used|done|did)|dispute|wrong|disagree|not true|galat|appeal|incorrect|mistake|गलत|ग़लत|गलती|सही नहीं|नहीं आता/i;

module.exports = {
  id: 'human',
  name: 'Human-in-the-Loop',
  icon: '🧑‍⚖️',
  describe: 'Sends the plan to a human counsellor for approval, lets the person dispute an AI decision, and reports the counsellor’s decision. Use for approval, counsellor, human review, disputes, complaints about the AI, or status of the review.',

  async run(ctx) {
    const { cf, message } = ctx;
    const dispute = DISPUTE.test(message || '');

    if (!dispute && (cf.status === 'approved' || cf.status === 'changes')) {
      const ok = cf.status === 'approved';
      return {
        replies: [{ text: ok ? 'Good news: your counsellor approved your plan.' : 'Your counsellor asked for a change before approving.',
          card: { type: 'handoff', status: cf.status, note: cf.counsellorNote, plan: summary(cf) } }],
        note: `reported ${cf.status}`, suggestions: []
      };
    }

    cf.status = 'sent';
    if (dispute) cf.counsellorNote = null;
    const hi = isHindi(cf, message);
    let removed = [];
    if (dispute && DENIES.test(message)) {
      const named = new Set(keywordSkills(message).map((k) => k.skill));
      const low = String(message).toLowerCase();
      removed = cf.skills.filter((s) => named.has(s.skill) || low.includes(label(s.skill).toLowerCase())).map((s) => s.skill);
      cf.skills = cf.skills.filter((s) => !removed.includes(s.skill));
      if (removed.length) cf.plan = null;   // the plan was built on those skills
    }
    const gone = removed.map(label).join(', ');
    const removedText = !removed.length ? '' : hi ? ` मैंने ${gone} आपके हुनर से हटा दिया है, इसलिए नौकरियाँ और प्लान अब इसके बिना बनेंगे।` : ` I’ve removed ${gone} from your skills, so jobs and plans no longer count it.`;
    const flagged = hi ? 'मैंने यह एक काउंसलर (इंसान) को भेज दिया है। वे आपका संदेश, AI की वजह और पूरा रिकॉर्ड देखेंगे, और AI का फ़ैसला बदल सकते हैं।'
      : 'I’ve flagged this for a human counsellor. They’ll see your message, the AI’s reasoning and the full trace, and they can overrule the AI.';
    const sent = hi ? 'मैंने आपका केस एक काउंसलर (इंसान) को भेज दिया है। किसी भी कंपनी तक कुछ भी पहुँचने से पहले वे हुनर, प्लान और निष्पक्षता रिपोर्ट जाँचेंगे।'
      : 'I’ve sent your case to a human counsellor. They check the skills, the plan and the fairness report before anything reaches an employer.';
    const noPlan = hi ? ' आपने अभी कोई प्लान नहीं बनाया है, इसलिए काउंसलर पहले सही नौकरी चुनने में मदद करेंगे।'
      : ' You don’t have a learning plan yet, so they’ll first help you pick the right job.';
    const text = dispute ? (removedText.trim() ? removedText.trim() + ' ' : '') + flagged : sent + (cf.plan ? '' : noPlan);
    return {
      replies: [{ text, card: { type: 'handoff', status: 'sent', dispute: dispute ? String(message).slice(0, 300) : null, removed: removed.map(label), plan: summary(cf) } }],
      note: dispute ? (removed.length ? `dispute recorded, removed ${gone}` : 'dispute recorded') : 'sent to counsellor',
      disputed: dispute ? String(message).slice(0, 300) : null,
      suggestions: [{ label: 'Open the counsellor view', href: '#/counsellor' }]
    };
  }
};

const summary = (cf) => ({
  skills: cf.skills.map((s) => label(s.skill)),
  role: cf.plan?.roleTitle || null,
  courses: cf.plan?.steps?.length ?? null,
  hours: cf.plan?.totalHours ?? null
});
