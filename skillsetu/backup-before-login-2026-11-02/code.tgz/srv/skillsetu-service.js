const cds = require('@sap/cds');
const lib = require('./agents/lib');
const orchestrator = require('./agents/orchestrator');
const sf = require('./integrations/successfactors');
const watch = require('./agents/watch');
const outbox = require('./agents/outbox');

const SkillSetuService = class SkillSetuService extends cds.ApplicationService {

  async init() {
    this.on('sendToSuccessFactors', async (req) => {
      const r = await sf.push(req.data.caseID, req.data.roleID || null);
      return r.error ? req.reject(r.error, r.message) : JSON.stringify(r);
    });
    this.on('sfPushes', async (req) => JSON.stringify(await sf.history(req.data.caseID || null)));

    this.on('impact', async () => {
      const { CaseFiles, ImpactDistricts, SFPushes } = lib.db();
      const [cases, districts, pushes] = await Promise.all([
        SELECT.from(CaseFiles).columns('status', 'skills', 'district'), SELECT.from(ImpactDistricts).orderBy('placed desc'), SELECT.from(SFPushes).where({ status: 'sent' })
      ]);
      const skills = cases.reduce((n, c) => n + lib.parse(c.skills, []).length, 0);
      return JSON.stringify({
        live: { cases: cases.length, hiddenSkills: skills, sentToCounsellor: cases.filter((c) => c.status !== 'active').length,
          approved: cases.filter((c) => c.status === 'approved').length, pushedToSuccessFactors: new Set(pushes.map((p) => p.caseFile_ID)).size },
        districts, synthetic: true
      });
    });

    /* ---------- Multi-agent chat ---------- */
    this.on('chat', async (req) => {
      const { caseID, message, intent, roleID, name } = req.data;
      if (!String(message || '').trim() && !intent) return req.reject(400, 'Send a message or an intent');
      return JSON.stringify(await orchestrator.handle({ caseID, message, intent, roleID, name }));
    });

    this.on('caseView', async (req) => {
      const v = await orchestrator.caseView(req.data.caseID);
      return v ? JSON.stringify(v) : req.reject(404, 'Case not found');
    });

    /* ---------- After-hire and job-risk watch ---------- */
    this.on('runWatch', async (req) => JSON.stringify(await watch.runWatch({ days: req.data.days || 0 })));
    this.on('outbox', async (req) => JSON.stringify(await outbox.list(req.data.caseID || null)));
    this.on('markHired', async (req) => {
      const { caseID, roleID } = req.data;
      const cf = caseID && await SELECT.one.from(lib.db().CaseFiles).columns('ID', 'targetRole_ID').where({ ID: caseID });
      if (!cf) return req.reject(404, 'Case not found');
      if (!roleID && !cf.targetRole_ID) return req.reject(400, 'Pick the role the person was hired into');
      return JSON.stringify(await orchestrator.handle({ caseID, force: 'growth', roleID: roleID || cf.targetRole_ID,
        forceReason: 'Counsellor marked the person as hired', extra: { hired: 'counsellor' } }));
    });
    // Background watch: a few minutes after start, then every 6 hours.
    if (!SkillSetuService._timer) {
      const tick = () => watch.runWatch().catch((e) => cds.log('watch').warn('watch failed', e.message));
      SkillSetuService._timer = setTimeout(() => { tick(); setInterval(tick, 6 * 3600e3).unref(); }, 3 * 60e3);
      SkillSetuService._timer.unref();
    }

    this.on('cases', async () => JSON.stringify(await orchestrator.listCases()));
    this.on('myCases', async (req) => {
      const ids = String(req.data.ids || '').split(',').map((s) => s.trim()).filter(Boolean).slice(0, 50);
      return JSON.stringify(ids.length ? await orchestrator.listCases(ids) : []);
    });

    this.on('reviewCase', async (req) => {
      const { caseID, decision, note } = req.data;
      if (!['approved', 'changes'].includes(decision)) return req.reject(400, 'decision must be "approved" or "changes"');
      const r = await orchestrator.review({ caseID, decision, note });
      return r ? JSON.stringify(r) : req.reject(404, 'Case not found');
    });

    await super.init();
  }
};
module.exports = SkillSetuService;
